<?php
/**
 * Author : Louis Richard, Michael Pedroletti
 * Creation Date : 26.DEC.2021
 * Last modification : 26.DEC.2021 :
 *      Created the file and modified the credentials
 */

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

require './phpmailer/Exception.php';
require './phpmailer/PHPMailer.php';
require './phpmailer/SMTP.php';

$inf=$_POST;

$message="Message from : ".$inf['fname']." ".$inf['name']."<br/> Message : <br/>".$inf['message']."<br/><br/> Sender email: ".$inf['email'];
$msg = "";

if (isset($inf['fname']) && isset($inf['name']) && isset($inf['email']) && isset($inf['message']))
{
    $mail=new PHPMailer(true);

    try{
        //Server settings
        $mail->SMTPDebug    = SMTP::DEBUG_OFF;
        $mail->isSMTP();
        $mail->SMTPAuth     = true;
        $mail->Host         = 'mail.infomaniak.ch';
        $mail->Username     = 'contact@wewfamily.ch';
        $mail->Password     = 'u2NDTv4Kp7eZqC2ehhWH';
        //$mail->SMTPSecure   = PHPMailer::ENCRYPTION_SMTPS;
        $mail->Port         = 587;
        $mail->SMTPOptions  = array(
                              'ssl' => array(
                                  'verify_peer'         => false,
                                  'verify_peer_name'    => false,
                                  'allow_self_signed'   => true
                              ));

        //Recipients
        $mail->setFrom('noreply@wewfamily.ch', 'No Reply');
        $mail->addAddress('contact@wewfamily.ch', 'WeW Family');

        //content
        $mail->isHTML(true);
        $mail->Subject      = "Contact form request";
        $mail->Body         = $message;

        $mail->send();
        $msg = "message sent";
    } catch (Exception $e){
        $msg = "message could not be sent. Mailer error : {$mail->ErrorInfo}";
    }
    $_GET['sent'] = true;
}
else {
    $msg = "fail isset";
    echo "<script>console.log('{$msg}')</script>";
    $_GET['sent'] = false;
}
require 'index.html';
